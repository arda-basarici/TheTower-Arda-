namespace Game
{
    public enum StatType
    {
        Health,
        Damage,
        FireRate,
        Speed,
        Range
    }
}