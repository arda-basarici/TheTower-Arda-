namespace Game
{
    public struct StatState : IState
    {
        public float CurrentValue { get; set; }
    }
}