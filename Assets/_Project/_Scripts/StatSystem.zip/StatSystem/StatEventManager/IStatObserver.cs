namespace Game
{
    public interface IStatObserver
    {
        void OnStatUpdated(StatState statState);
        void OnStatSynced(StatState statState);
    }
}