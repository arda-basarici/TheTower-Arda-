namespace Game
{
    public class StatEventManager : EventManager<StatState>
    {
        private readonly StatType statName;
        private StatState currentState;

        public StatEventManager(StatType statName)
        {
            this.statName = statName;
            currentState = new StatState { CurrentValue = 0 };
        }

        /// <summary>
        /// Updates the stat and notifies observers.
        /// </summary>
        public void UpdateStat(float currentValue, float maxValue)
        {
            currentState.CurrentValue = currentValue;

            NotifyStateObservers(currentState);
        }
    }
}
