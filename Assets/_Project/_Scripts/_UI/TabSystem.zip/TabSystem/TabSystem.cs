using System.Collections.Generic;

namespace Game
{
    public static class TabSystem
    {
        private static readonly Dictionary<TabManagers, TabManager> _tabManagers = new Dictionary<TabManagers, TabManager>();
        public static void RegisterTabManager(TabManagers tabManager, TabManager tabManagerInstance)
        {
            if (!_tabManagers.ContainsKey(tabManager))
            {
                _tabManagers.Add(tabManager, tabManagerInstance);
            }
        }

        public static void UnregisterTabManager(TabManagers tabManager)
        {
            if (_tabManagers.ContainsKey(tabManager))
            {
                _tabManagers.Remove(tabManager);
            }
        }

        public static TabManager GetTabManager(TabManagers tabManager)
        {
            if (_tabManagers.ContainsKey(tabManager))
            {
                return _tabManagers[tabManager];
            }
            return null;
        }

        public static void Show<T>() where T : TabPanel
        {
            foreach (var tabManager in _tabManagers)
            {
                foreach (var tabPanel in tabManager.Value.tabPanels)
                {
                    if (tabPanel is T view)
                    {
                        tabManager.Value.Show(view);
                        return;
                    }
                }
            }

        }

        public static void Show(TabPanel tabPanel)
        {
            foreach (var tabManager in _tabManagers)
            {
                if(tabManager.Value.tabPanels.Contains(tabPanel))
                {
                    tabManager.Value.Show(tabPanel);
                    return;
                }
            }
        }
    }
}