using UnityEngine;

namespace Game
{
    public class ShopPanel : TabPanel
    {
        public override void Initialize()
        {
            // do something
        }
    }
}
