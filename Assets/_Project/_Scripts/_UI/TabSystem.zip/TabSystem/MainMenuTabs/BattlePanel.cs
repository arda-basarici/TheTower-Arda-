using UnityEngine;

namespace Game
{
    public class BattlePanel : TabPanel
    {
        public override void Initialize()
        {
            // do something
        }
    }
}
