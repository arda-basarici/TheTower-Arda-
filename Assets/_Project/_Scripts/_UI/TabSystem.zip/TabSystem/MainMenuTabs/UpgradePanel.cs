using UnityEngine;

namespace Game
{
    public class UpgradePanel : TabPanel
    {
        public override void Initialize()
        {
            // do something
        }
    }
}
