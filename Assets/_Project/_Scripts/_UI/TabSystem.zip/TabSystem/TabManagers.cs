namespace Game {
    public enum TabManagers
    {
        MainMenu,
        MenuUpgrades,
        InGameUpgrades
    }
}